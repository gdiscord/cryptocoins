# for constants which need to be accessed by various parts of Sentinel

# skip proposals on superblock creation if the SB isn't within the fudge window
SUPERBLOCK_FUDGE_WINDOW = 60 * 60 * 2
